-- Максимальное количество гильз
local MAX_CASINGS = 5
local casingQueue = {}
local pendingRemovals = {}  -- Очередь на удаление
local isProcessing = false

-- Функция для проверки наличия тега casing у предмета
local function HasCasingTag(item)
    if not item or not item.Prefab then return false end
    
    local success, result = pcall(function()
        local tags = item.Prefab.Tags
        if not tags then return false end
        
        for tag in tags do
            if tag == "casing" then
                return true
            end
        end
        return false
    end)
    
    return success and result or false
end

-- Функция для плавного удаления гильз
local function ProcessRemovals()
    if isProcessing then return end
    isProcessing = true
    
    -- Удаляем по 5 гильз за раз с интервалом
    local function RemoveBatch()
        if #pendingRemovals == 0 then
            isProcessing = false
            return
        end
        
        -- Удаляем до 5 гильз за раз
        local batchCount = math.min(5, #pendingRemovals)
        for i = 1, batchCount do
            local item = table.remove(pendingRemovals, 1)
            if item and not item.Removed then
                pcall(function()
                    item.Remove()
                end)
            end
        end
        
        -- Если остались еще гильзы, планируем следующую партию
        if #pendingRemovals > 0 then
            Timer.Wait(RemoveBatch, 50)  -- 50мс между партиями
        else
            isProcessing = false
        end
    end
    
    RemoveBatch()
end

-- Отслеживание создания гильз
Hook.Add("item.created", "CasingTracker.OnItemCreated", function(item)
    if not item then return end
    
    if HasCasingTag(item) then
        -- Добавляем гильзу в конец очереди
        table.insert(casingQueue, item)
        
        -- Если превышен лимит, добавляем старые гильзы в очередь на удаление
        while #casingQueue > MAX_CASINGS do
            local oldestCasing = table.remove(casingQueue, 1)
            if oldestCasing and not oldestCasing.Removed then
                table.insert(pendingRemovals, oldestCasing)
            end
        end
        
        -- Запускаем процесс удаления если не запущен
        if #pendingRemovals > 0 and not isProcessing then
            ProcessRemovals()
        end
    end
end)

-- Очистка очереди от удаленных предметов
Timer.Wait(function()
    local function CleanupQueues()
        -- Очистка основной очереди
        for i = #casingQueue, 1, -1 do
            local item = casingQueue[i]
            if not item or item.Removed then
                table.remove(casingQueue, i)
            end
        end
        
        -- Очистка очереди на удаление
        for i = #pendingRemovals, 1, -1 do
            local item = pendingRemovals[i]
            if not item or item.Removed then
                table.remove(pendingRemovals, i)
            end
        end
    end
    
    CleanupQueues()
end, 5000, true)  -- Каждые 5 секунд

-- Инициализация при загрузке
Timer.Wait(function()
    -- Собираем все существующие гильзы
    for i = 1, #Item.ItemList do
        local item = Item.ItemList[i]
        if item and not item.Removed and HasCasingTag(item) then
            table.insert(casingQueue, item)
        end
    end
    
    -- Если гильз больше лимита, добавляем лишние в очередь на удаление
    while #casingQueue > MAX_CASINGS do
        local oldestCasing = table.remove(casingQueue, 1)
        if oldestCasing and not oldestCasing.Removed then
            table.insert(pendingRemovals, oldestCasing)
        end
    end
    
    print("Начальное количество гильз: " .. #casingQueue)
    
    -- Запускаем удаление если есть что удалять
    if #pendingRemovals > 0 then
        ProcessRemovals()
    end
end, 1000)